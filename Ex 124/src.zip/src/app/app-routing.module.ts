import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ProducttableComponent } from './producttable/producttable.component';
import { ProductComponent } from './product/product.component';
import { AboutComponent } from './about/about.component';
import { ServiceProductHttpComponent } from './service-product-http/service-product-http.component';
import { BooksComponent } from './books/books.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { FashionComponent } from './fashion/fashion.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
const routes: Routes = [
  {path:'dang-nhap', component:LoginComponent},
  {path:'simple-product',component:ProductComponent},
  {path:'advanced-product', component:ProducttableComponent},
  {path:'intro-product',component:AboutComponent},
  {path: 'product-http', component:ServiceProductHttpComponent},
  {path: 'book-http', component:BooksComponent},
  {path: 'book-detail', component: BookDetailComponent},
  {path: 'fashion-upload', component:FashionComponent},
  {path:'file-upload', component:FileUploadComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
