export interface IBook{ 
    BookId:string, 
    BookName:string, 
    Price:number, 
    Image:string 
    }