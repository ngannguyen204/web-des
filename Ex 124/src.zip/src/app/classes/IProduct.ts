export interface IProduct{ 
    ProductId:string, 
    ProductName:string, 
    Price:number, 
    Image:string   
    } 
//không nên để trống , 
// nên liệt kê đầy đủ cấu trúc cái này ra luôn 
