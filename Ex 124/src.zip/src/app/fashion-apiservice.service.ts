import { HttpClient, HttpErrorResponse, HttpHeaders } from 
'@angular/common/http'; 
import { Injectable } from '@angular/core'; 
import { catchError, map, Observable, retry, throwError } from 'rxjs'; 
import { Fashion } from './classes/Fashion'; 
 
@Injectable({ 
  providedIn: 'root' 
}) 
export class FashionAPIService { 
 
  constructor(private _http: HttpClient) { }   
  getFashions():Observable<Fashion[]> {
  /*{ 
    const headers=new HttpHeaders().set("Content-Type","text/plain;charset=utf-8") 
    const requestOptions:Object={ 

    } */
    return this._http.get<Fashion[]>("/fashions", {
      headers: new HttpHeaders().set("Accept", "application/json") // ✅ Yêu cầu JSON
    }).pipe( 
        retry(3), 
        catchError(this.handleError)) 
  } 
  handleError(error:HttpErrorResponse){ 
    return throwError(()=>new Error(error.message)) 
  } 
} 