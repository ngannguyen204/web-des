import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AboutComponent } from './about/about.component';
import { RouterModule, ROUTES } from '@angular/router'; //MỚI
import {  HttpClientModule } from '@angular/common/http';
import { ServiceProductHttpComponent } from './service-product-http/service-product-http.component';
import { BooksComponent } from './books/books.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { FashionComponent } from './fashion/fashion.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AboutComponent,
    ServiceProductHttpComponent,
    BooksComponent,
    BookDetailComponent,
    FileUploadComponent,
    FashionComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([]), //MỚI
    HttpClientModule
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

