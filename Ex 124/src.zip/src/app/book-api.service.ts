/* import { HttpClient, HttpErrorResponse, HttpHeaders } from 
'@angular/common/http'; 
import { Injectable } from '@angular/core'; 
import { catchError, map, Observable, retry, throwError } from 'rxjs'; 
import { IBook } from './classes/Book'; 
@Injectable({ 
providedIn: 'root' 
}) 
export class BookAPIService { 
  private _url: string = "assets/data/books.json";
constructor(private _http: HttpClient) { } 
getBooks():Observable<any>
{ 
  const headers=new HttpHeaders().set("Content-Type","text/plain;charset=utf-8") 

return this._http.get<IBook[]>(this._url).pipe(
  retry(3),
  catchError(this.handleError)
);
}

handleError(error:HttpErrorResponse){ 
  return throwError(()=>new Error(error.message)) 
} 
} */ //BÀI 114

import { HttpClient, HttpErrorResponse, HttpHeaders } from 
'@angular/common/http'; 
import { Injectable } from '@angular/core';
import { catchError, map, Observable, retry, throwError } from 'rxjs'; 
import { IBook } from './classes/Book'; 
 
@Injectable({ 
  providedIn: 'root' 
}) 
export class BookAPIService { 
  private _url: string = "assets/data/books.json";
  constructor(private _http: HttpClient) { } 
   
  getBooks():Observable<any> 
  { 
    const headers=new HttpHeaders().set("Content-Type","text/plain;charset=utf-8") 
    //const requestOptions:Object={ 
      //headers:headers, 
      //responseType:"text" 
   // } 
    return this._http.get<any>(this._url).pipe(
      retry(3),
      catchError(this.handleError)
    );
    }
  handleError(error:HttpErrorResponse){ 
    return throwError(()=>new Error(error.message)) 
  } 
 
  getBook(bookId:string):Observable<IBook | undefined> 
  { 
    const headers=new HttpHeaders().set("Content-Type","text/plain;charset=utf-8") 
   // return this._http.get<any>("/books/"+bookId,requestOptions).pipe( 
        //map(res=>JSON.parse(res) as IBook), 
        //retry(3), 
  //      catchError(this.handleError)) 
 
    return this._http.get<IBook[]>(this._url).pipe(
      map(books => books.find(book => book.BookId === bookId)), // ✅ Tìm sách theo ID
      catchError(this.handleError)
    );
  } 
} 