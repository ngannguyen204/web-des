import { Component } from '@angular/core';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-producttable',
  imports: [CommonModule],
  templateUrl: './producttable.component.html',
  styleUrl: './producttable.component.css'
})
export class ProducttableComponent {
  public products:any;
  constructor(private ps:ProductService){
    this.products=ps.get_list_products()
  }
}

