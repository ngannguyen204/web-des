import { HttpClient, HttpEventType } from '@angular/common/http'; 
import { Component, Input } from '@angular/core'; 
import { finalize, Subscription } from 'rxjs'; 
@Component({ 
selector: 'app-file-upload', 
standalone:false,
templateUrl: './file-upload.component.html', 
styleUrls: ['./file-upload.component.css'] 
}) 
/*export class FileUploadComponent { 
@Input() 
requiredFileType:any; 
fileName = ''; 
uploadProgress:number=0; 
images:string[] = []; //LIST ẢNH
uploadSub: Subscription=new Subscription(); 
constructor(private http: HttpClient) {} 
onFileSelected(event:any) { 
const file:File = event.target.files[0];     
if (file) { 
this.fileName = file.name; 
const formData = new FormData(); 
formData.append("image", file); 
const upload$ = this.http.post("/upload", formData, { 
reportProgress: true, 
observe: 'events' 
}) 
.pipe( 
finalize(() => this.reset()) 
);         
this.uploadSub = upload$.subscribe(event => { 
if (event.type == HttpEventType.UploadProgress) { 
this.uploadProgress = Math.round(100 * (event.loaded / 
event.total!)); 
} 
}) 
} 
} 
cancelUpload() { 
this.uploadSub.unsubscribe(); 
this.reset(); 
} 
reset() { 
this.uploadProgress = 0; 
this.uploadSub = new Subscription(); 
} 
} CŨ*/

export class FileUploadComponent {
  fileName = '';
  uploadProgress = 0;
  images: string[] = []; // Danh sách ảnh

  constructor(private http: HttpClient) {}

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      this.fileName = file.name;
    }
  }

  onUpload() {
    const inputElement = document.querySelector('input[type="file"]') as HTMLInputElement;
    if (!inputElement || !inputElement.files || inputElement.files.length === 0) {
      return;
    }

    const file = inputElement.files[0];
    const formData = new FormData();
    formData.append("image", file);

    this.http.post("http://localhost:3001/upload", formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      finalize(() => this.loadAlbum()) // Tự động load album sau upload
    ).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.uploadProgress = Math.round(100 * (event.loaded / event.total!));
      }
    });
  }

  loadAlbum() {
    this.http.get<string[]>("http://localhost:3001/images").subscribe(
      (data) => { 
        this.images = data; 
        console.log("Ảnh tải về:", this.images); // 
      },
      (err) => { 
        console.error('Lỗi khi tải danh sách ảnh', err); 
      }
    );
  }
  
}