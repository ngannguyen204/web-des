import { Injectable } from '@angular/core';
import { IProduct } from './classes/IProduct';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ProductHttpService {
  private _url:string="assets/data/products.json"; 
  constructor(private _http: HttpClient) { } 
  getProducts():Observable<IProduct[]>{     
  return this._http.get<IProduct[]>(this._url) 
  } 
  } 