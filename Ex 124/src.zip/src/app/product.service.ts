import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products:any
  constructor() { }
 get_list_products(){
    this.products=[
      {"id":"1","name":"coca","price":"100"},
      {"id":"2","name":"pepsi","price":"250"},
      {"id":"3","name":"sting","price":"300"},
      {"id":"4","name":"aqua","price":"120"},
      {"id":"5","name":"7up","price":"290"}
      ]
      return this.products
  }
}
