const express = require('express');
const fileUpload = require('express-fileupload');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3001;

app.use(cors());
app.use(fileUpload());
app.use(express.static('public'));
app.use('/upload', express.static(path.join(__dirname, 'upload')));

// Tạo thư mục `upload/` nếu chưa tồn tại
const uploadDir = path.join(__dirname, 'upload');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// API UPLOAD FILE
app.post('/upload', (req, res) => {
    if (!req.files || !req.files.image) {
        return res.status(400).json({ message: 'No files were uploaded.' });
    }

    let image = req.files.image;
    let uploadPath = path.join(uploadDir, image.name);

    image.mv(uploadPath, function(err) {
        if (err) return res.status(500).json({ message: 'Upload failed', error: err });

        res.json({ imageUrl: `http://localhost:3001/upload/${image.name}` });
    });
});

// API LẤY DANH SÁCH ẢNH
app.get('/images', (req, res) => {
    fs.readdir(uploadDir, (err, files) => {
        if (err) {
            return res.status(500).json({ message: 'Cannot read directory', error: err });
        }

        const images = files.map(file => `http://localhost:3001/upload/${file}`);
        res.json(images);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
